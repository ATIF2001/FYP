import './App.css'
import Login from './components/Auth/Login'
import 'antd/dist/reset.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Dashboard from './components/Dashboard/Dashboard'
import ProtectedRoute from './components/ProtectedRoute'
import TopStories from './components/Top Stories/TopStories'
import Story from './components/Top Stories/Story'

function App () {
  return (
    <>
      <BrowserRouter>
      <Dashboard/>
      <Routes>
      <Route
      exact path='/topstories'
      element={<TopStories key="topstories" category="general"/>}
      />
      <Route
      exact path='/sports'
      element={<TopStories 
        key="sports" category="sports"/>}
      />
      <Route
      exact path='/science'
      element={<TopStories 
        key="science" category="science"/>}
      />
      <Route
      exact path='/entertainment'
      element={<TopStories 
        key="entertainment" category="entertainment"/>}
      />
      <Route
      exact path='/health'
      element={<TopStories 
        key="health" category="health"/>}
      />
      <Route
      exact path='/technology'
      element={<TopStories 
        key="technology" category="technology"/>}
      />
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
