import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import Cookies from 'js-cookie'

const baseUrl = 'http://127.0.0.1:3001/api/v1'

export const nodeApi = createApi({
  reducerPath: 'nodeApi',
  baseQuery: fetchBaseQuery({ baseUrl }),

  tagTypes: ['Users', 'Channel'],

  endpoints: builder => ({})
})

export const {} = nodeApi
