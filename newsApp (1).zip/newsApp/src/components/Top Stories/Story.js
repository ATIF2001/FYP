import { Tag, FloatButton, Row, Col } from 'antd'
import React from 'react'
import './TopStories.css'
const { BackTop } = FloatButton

const Story = () => {
  return (
    <>
      <div className='bold fs-28'>
        Leak: Samsung to announce the Z Fold 3 and Galaxy Watch 4 in August
      </div>
      <div className='mt-rem-1'>
        <Tag color='#2F9FF8'>Tech</Tag>
        <Tag color='#2F9FF8'>Mobile</Tag>
      </div>
      <div className='fs-17 mt-rem-1 text-muted'>
        Samsung's next Unpacked event reportedly lands August 11
      </div>
      <div className='mt-rem-1'>
        <img
          src={require('./../../images/tablet.png')}
          alt=''
          className='w-86'
        />
      </div>
      <div className='mt-rem-2 text-muted fs-17 w-86'>
        Samsung had a pretty quiet Mobile World Congress event, but it did tell
        us we’d learn more about its upcoming Google-approved smartwatch at its
        next Unpacked event. Unfortunately, the company didn’t tell us when
        exactly that would be, but a new report from Korean publication
        DigitalDaily News (via 9to5Google) claims the next Unpacked will take
        place on August 11, at 10 AM ET.
      </div>
      <div className='mt-rem-2 text-muted fs-17'>
        According to the report, Samsung will be launching five devices at the
        event:
      </div>
      <div className='mt-rem-2'>
        <ul
          className='fs-17 text-muted'
          style={{ listStyleType: 'square', listStylePosition: 'inside' }}
        >
          <li>Galaxy Z Fold 3</li>
          <br />
          <li>Galaxy Z Flip 3</li>
          <br />
          <li>Galaxy Watch 4</li>
          <br />
          <li> Active Galaxy Buds 2</li>
        </ul>
      </div>
      <div className='mt-rem-2 fs-17 text-muted w-86'>
        Notably, the new Galaxy Watches will be Samsung’s first to not use Tizen
        OS. Google collaborated with Samsung to revamp Wear OS from the ground
        up, making it smoother and more efficient.
        <br />
        <br />
        <br />
        Hopefully, the devices are able to maintain the long battery life
        Samsung’s smartwatches have been known for, while having much greater
        compatibility with smartwatch apps via Wear OS. That said, the watch
        will use a custom One UI Watch skin — because it wouldn’t be Samsung if
        it didn’t put its own twist on the software.
        <br />
        <br />
        <br />
        As for the Z Fold 3, it’s expected to be a refinement of the original
        Fold’s concept without major changes to the form factor. The biggest
        change aside from the expected spec bump is that the Z Fold 3 will
        support the S-Pen.
        <br />
        <br />
        <br />
        The event will reportedly be broadcast via YouTube, as per usual, and
        there is no indication the company plans to hold a concurrent physical
        event. With the rumored date a little over a month away, I’d expect an
        official announcement from Samsung within the next week or two.
      </div>
      <div className='mt-rem-2 fs-12 text-center w-86'>
        <div className='text-muted'>Published July 5, 2021 - 8:16 pm IST</div>
        <div className='p-5'>by John Abraham</div>
      </div>
      <div className='mt-rem-2'>
        <BackTop>
          <div className='fs-12'>Back to top</div>
        </BackTop>
      </div>
      <Row className='mt-rem-2 bold'>
        <Col xs={4} className='fs-17'>
          Add your comment
        </Col>
        <Col xs={17} style={{ marginTop: '2px' }} className='text-muted'>
          <hr />
        </Col>
      </Row>
    </>
  )
}

export default Story
