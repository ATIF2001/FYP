import React from 'react'
import { Card, Row, Col } from 'antd'
import './TopStories.css'
import ShareSvg from './../../images/share.svg'
import PocketSvg from './../../images/pocket.svg'

const StoriesCard = ({size, title, desc, author, imageUrl, date}) => {
  
  
  return (
    <>
      {size === 'large' ? (
        <div className='story_card'>
          <Card
            style={{
              width: 914
            }}
          >
            <div className='space-between'>
              <div>
                <div style={{ fontWeight: 500 }} className='fs-17'>
                  Samsung Galaxy F22 launched in India: Price, features, other
                  details
                </div>
                <div className='text-muted' style={{ width: '90%' }}>
                  Samsung Galaxy F22 has been launched in India. The new
                  smartphone has been priced in the mid-range segment. The new
                  smartphone is powered by a MediaTek chipset and features a
                  high refresh rate AMOLED display.
                </div>
                <Row
                  style={{
                    paddingTop: '1rem'
                  }}
                >
                  <Col xs={4}>The Mint</Col>
                  <Col xs={4}>15 mins ago</Col>
                  <Col xs={1}></Col>
                  <Col xs={4}>
                    <span style={{ color: '#0768B5' }}>
                      <img src={ShareSvg} alt='' />
                      &nbsp; Share
                    </span>
                  </Col>
                  <Col xs={4}>
                    <span style={{ color: '#0768B5' }}>
                      <img src={PocketSvg} alt='' />
                      &nbsp; Read Later
                    </span>
                  </Col>
                </Row>
              </div>
              <div>
                <img
                  src={require('./../../images/phones.png')}
                  alt=''
                  style={{ width: '170px' }}
                />
              </div>
            </div>
          </Card>
        </div>
      ) : (
        <div className='story_card'>
          <Card
            style={{
              width: "420px",
              height: "330px"
            }}
          >
            <div className='space-between'>
              <div>
                <div className='fs-17' style={{ fontWeight: 500 }}>
                  {title}
                </div>
                <div className='text-muted' style={{ width: '90%' }}>
                 {desc}
                </div>
              </div>
              <div>
                <img
                  src={imageUrl}
                  alt=''
                  style={{ width: '160px' }}
                />
              </div>
            </div>
            <Row
              style={{
                paddingTop: '1rem'
              }}
            >
              <Col xs={6}>{author}</Col>
              <Col xs={6}>{date}</Col>
              <Col xs={6}>
                <span style={{ color: '#0768B5' }}>
                  <img src={ShareSvg} alt='' />
                  &nbsp; Share
                </span>
              </Col>
              <Col xs={6}>
                <span style={{ color: '#0768B5' }}>
                  <img src={PocketSvg} alt='' />
                  &nbsp; Read Later
                </span>
              </Col>
            </Row>
          </Card>
        </div>
      )}
    </>
  )
}

export default StoriesCard
