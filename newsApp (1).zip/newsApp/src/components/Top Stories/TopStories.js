import React, { useState, useRef , useEffect} from 'react'
import './TopStories.css'
import { Tag, Row, Col, Carousel } from 'antd'
import { MoreOutlined } from '@ant-design/icons'
import FeatherSvg from './../../images/feather.svg'
import ArrowLeftLineSvg from './../../images/arrowleftwithline.svg'
import ArrowRightLineSvg from './../../images/arrowrightwithline.svg'
import ArrowLeftLineDisabledSvg from './../../images/arrowleftwithlinedisabled.svg'
import ArrowRightLineDisabledSvg from './../../images/arrowrightwithlinedisabled.svg'
import StoriesCard from './StoriesCard'
import FollowCard from './FollowCard'
import { Link, useNavigate } from 'react-router-dom'
const { CheckableTag } = Tag

const TopStories = ({category}) => {
  let navigate = useNavigate()
  const carouselRef = useRef(null)
  const [currentSlide, setCurrentSlide] = useState(0)

  const onFollowCardChange = currentSlidee => {
    setCurrentSlide(currentSlidee)
    console.log(currentSlidee)
  }
  
  const tagsData = [
    'All',
    'Books',
    'Music',
    'Sports',
    'Android',
    'Google',
    'Iphone',
    'Nano Technology',
    'Samsung'
  ]
  const [selectedTags, setSelectedTags] = useState(['All'])
  const handleChange = (tag, checked) => {
    const nextSelectedTags = checked
      ? [...selectedTags, tag]
      : selectedTags.filter(t => t !== tag)
    setSelectedTags(nextSelectedTags)
  }
  const APIKey= "d0b69496c18e463f888a273cb521ea9f";
  const [newsArticles, setNewsArticles] = useState([]);
  const getNews = async ()=>{
    let url = await fetch(`https://newsapi.org/v2/top-headlines?category=${category}&apiKey=${APIKey}&pageSize=100`);
    let parsedData = await url.json();
    setNewsArticles(parsedData.articles);
    console.log(parsedData.articles);
  }
  useEffect(() => {
    getNews();
  }, [])
  return (
    <>
      <div className='bold fs-20'>Top Stories for You</div>
      <Row>
        <Col xs={18}>
          {/* <div style={{ marginTop: '1.5rem' }}>
            {tagsData.map(tag => (
              <Link to={selectedTags}>
              <CheckableTag
                key={tag}
                onClick={handleClick(tag)}
                checked={selectedTags.indexOf(tag) > -1}
                className='fs-15'
                onChange={checked => handleChange(tag, checked)}
                style={{
                  boxShadow: '0px 2px 20px rgba(0, 0, 0, 0.04)',
                  borderRadius: '20px',
                  padding: '5px 12px',
                  marginLeft: '0.7rem'
                }}
              >
                {tag}
              </CheckableTag>
              </Link>
            ))}
            <span style={{ marginLeft: '10px', fontSize: '1.7rem' }}>
              <MoreOutlined style={{ transform: 'rotate(90deg)' }} />
            </span>
          </div> */}
          < div className='fs-15'>
          <Link to="/topstories">
          All 
          </Link>
          <Link to="/sports">
          Sports 
          </Link>
          <Link to="/science">
          Science 
          </Link>
          <Link to="/entertainment">
          Entertainment 
          </Link>
          <Link to="/health">
          Health 
          </Link>
          <Link to="/technology">
          Technology 
          </Link>
          
          </div>

          <div style={{ margin:'10px', width: '1000px', flexWrap:'wrap' }} className='flex'>
            {
              newsArticles.map(((news, key)=>(
                <div  style={{margin: '3px'}}>
                <Link to='/dashboard/topstories/story'>
                  <StoriesCard key={key} title={news.title} desc={news.description} author={news.author} imageUrl={news.urlToImage} date={news.publishedAt} />
                </Link>
              </div >
              )))
            }
           
          </div>
          <div style={{ marginTop: '2rem' }} className='flex'>
          
          </div>
          <div
            className='bold fs-20 space-between'
            style={{ marginBlock: '2rem' }}
          >
            <div>
              <img src={FeatherSvg} alt='' />
              &nbsp; Creators you should follow
            </div>
            <div style={{ marginRight: '6rem' }}>
              {currentSlide === 0 ? (
                <img src={ArrowLeftLineDisabledSvg} alt='' />
              ) : (
                <img
                  src={ArrowLeftLineSvg}
                  alt=''
                  onClick={() => {
                    carouselRef.current.prev()
                  }}
                />
              )}
              &nbsp;&nbsp;&nbsp;&nbsp;
              {currentSlide === 1 ? (
                <img src={ArrowRightLineDisabledSvg} alt='' />
              ) : (
                <img
                  src={ArrowRightLineSvg}
                  alt=''
                  onClick={() => {
                    carouselRef.current.next()
                  }}
                />
              )}
            </div>
          </div>
          <div className='follow_cards'>
            <Carousel
              ref={carouselRef}
              afterChange={onFollowCardChange}
              style={{ width: '100%', margin: 0, position: 'absolute' }}
              dots={false}
            >
              <div>
                <Row>
                  <Col xs={3} style={{ margin: '1.2rem'  }}>
                    <FollowCard />
                  </Col>
                  <Col xs={3} style={{margin: '1.2rem'  }}>
                    <FollowCard />
                  </Col>
                  <Col xs={3} style={{ margin: '1.2rem'  }}>
                    <FollowCard />
                  </Col>
                  <Col xs={3} style={{ margin: '1.2rem'  }}>
                    <FollowCard />
                  </Col>
                  <Col xs={3} style={{ margin: '1.2rem' }}>
                    <FollowCard />
                  </Col>
                </Row>
              </div>
              <div>
                <Row>
                  <Col xs={4}>
                    <FollowCard />
                  </Col>
                </Row>
              </div>
            </Carousel>
          </div>
        </Col>
      </Row>
    </>
  )
}

export default TopStories
