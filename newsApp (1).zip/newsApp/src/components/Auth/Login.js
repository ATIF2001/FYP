import React, { useState } from 'react'
import { Col, Row } from 'antd'
import { Button, Form, Input } from 'antd'
import { message } from 'antd'
import './Login.css'
import Cookie from 'js-cookie'
import { useNavigate } from 'react-router-dom'
import {
  MailOutlined,
  EyeOutlined,
  ArrowRightOutlined
} from '@ant-design/icons'

export default function Login () {
  const navigate = useNavigate()

  const [loading, setLoading] = useState(false)

  const onFinish = values => {}

  const onFinishFailed = errorInfo => {
    message.error('Login failed')
  }

  return (
    <>
      <Row>
        <Col span={13}>
          <div style={{ height: '100vh' }}>
            <img
              className='login_img'
              // src={require('./../../login.png')}
              alt='svg'
            />
          </div>
        </Col>
        <Col span={11}>
          <div className='login_form'>
            <div
              style={{
                width: '80%',
                marginLeft: 'auto',
                marginRight: 'auto'
              }}
            >
              <p
                style={{
                  textAlign: 'center',
                  fontSize: '1.8rem',
                  fontWeight: 'bold',
                  marginBottom: 45
                }}
              >
                TvChannel Login
              </p>
              <Form
                name='basic'
                initialValues={{
                  remember: true
                }}
                labelCol={{
                  span: 8
                }}
                wrapperCol={{
                  span: 24
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
              >
                <Form.Item
                  name='email'
                  hasFeedback
                  rules={[
                    {
                      type: 'email',
                      required: true,
                      message: 'Please enter your email'
                    }
                  ]}
                >
                  <Input
                    placeholder='Email'
                    prefix={<MailOutlined />}
                    className='input_email_icon'
                    style={{
                      borderRadius: '30px',
                      padding: '8px 8px 8px 15px',
                      background: 'rgb(242, 242, 242)'
                    }}
                  />
                </Form.Item>

                <Form.Item
                  name='password'
                  hasFeedback
                  rules={[
                    {
                      required: true,
                      message: 'Please enter your passowrd'
                    }
                  ]}
                >
                  <Input.Password
                    placeholder='Password'
                    className='input_password_icon'
                    prefix={<EyeOutlined />}
                    style={{
                      borderRadius: '30px',
                      padding: '8px 8px 8px 15px',
                      background: 'rgb(242, 242, 242)'
                    }}
                  />
                </Form.Item>

                <Form.Item style={{ textAlign: 'center' }}>
                  <Button
                    htmlType='submit'
                    style={{
                      width: '100%',
                      height: '2.6rem',
                      borderRadius: '30px',
                      background: '#e4b303',
                      fontWeight: 'bold'
                    }}
                    loading={loading}
                  >
                    Login
                  </Button>
                </Form.Item>
              </Form>
              <div style={{ fontWeight: 'bold', textAlign: 'center' }}>
                <span style={{ opacity: 0.7 }}>Forgot </span>
                <span style={{ opacity: 0.8 }}> Email / Password</span>
              </div>
              <div
                style={{
                  marginTop: '6rem',
                  textAlign: 'center',
                  opacity: 0.7,
                  fontWeight: 'bold'
                }}
              >
                Create Account&nbsp;&nbsp;
                <span>
                  <ArrowRightOutlined />
                </span>
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </>
  )
}
